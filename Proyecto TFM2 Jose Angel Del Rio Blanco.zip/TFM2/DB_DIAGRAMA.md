# Diagrama de la Base de Datos (MySQL)

Se incluye un diagrama ER en formato Mermaid. Para visualizar gráficamente, copia el siguiente bloque en un editor compatible (VSCode con extensión "Markdown Preview Enhanced" o en el "Mermaid Live Editor"):

```mermaid
erDiagram
    USERS {
        int id PK
        varchar username
        varchar password
        enum role
    }
    ACTIVE_USERS {
        int user_id FK
        datetime last_alive
    }
    CONTACTOS {
        int id PK
        varchar nombre
        varchar email
        text mensaje
        timestamp creado_en
    }
    NEWSLETTER {
        int id PK
        varchar email
    }
    DIGIMON {
        int id PK
        varchar name
        varchar level
        varchar attribute
        varchar img
    }
    USERS ||--o{ ACTIVE_USERS : "tiene"
```
