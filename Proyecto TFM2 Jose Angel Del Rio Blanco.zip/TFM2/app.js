require('dotenv').config();

const express = require('express');
const path    = require('path');
const app     = express();
const db      = require('./db');


app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));


const contactoRoutes   = require('./routes/contactoRoutes');
const digimonRoutes    = require('./routes/digimonRoutes');
const newsletterRoutes = require('./routes/newsletterRoutes');
const authRoutes       = require('./routes/authRoutes');
const { verifyToken, requireAdminMiddleware } = require('./middleware/authMiddleware');


app.use('/api/contacto',   contactoRoutes);
app.use('/api/digimon',     digimonRoutes);
app.use('/api/newsletter',  newsletterRoutes);
app.use('/api',             authRoutes);


app.use('/api', (req, res) => {
  res.status(404).json({ success: false, error: 'Ruta API no encontrada.' });
});


app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

app.get('/admin.html', verifyToken, requireAdminMiddleware, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});


debugger;
const axios = require('axios');
(async function loadDigimonsOnStart() {
  try {
    const [rows] = await db.query('SELECT COUNT(*) AS count FROM digimon');
    const { count } = rows[0];
    if (count > 0) {
      console.log(`La tabla digimon ya tiene ${count} registros. No se insertarán duplicados.`);
      return;
    }

    const response = await axios.get('https://digimon-api.vercel.app/api/digimon');
    const digimons   = response.data;

    for (let digi of digimons) {
      await db.query(
        'INSERT INTO digimon (name, level, attribute, img) VALUES (?, ?, ?, ?)',
        [digi.name, digi.level, digi.attribute || null, digi.img]
      );
    }
    console.log(`✔ Se cargaron ${digimons.length} digimons en la base de datos.`);
  } catch (error) {
    console.error('Error al cargar datos de Digimon:', error);
  }
})();


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor escuchando en puerto ${PORT}`));