const express = require('express');
const router  = express.Router();
const db      = require('../db');


router.post('/', async (req, res) => {
  const { nombre, email, mensaje } = req.body;
  if (!nombre || !email || !mensaje) {
    return res
      .status(400)
      .json({ success: false, error: 'Faltan campos obligatorios.' });
  }

  try {
    
    const [result] = await db.query(
      'INSERT INTO contactos (nombre, email, mensaje) VALUES (?, ?, ?)',
      [nombre, email, mensaje]
    );
    return res.json({ success: true, id: result.insertId });
  } catch (err) {
    console.error('ERROR DB (contacto):', err);
    return res
      .status(500)
      .json({ success: false, error: 'Error al guardar en la base de datos.' });
  }
});

module.exports = router;
