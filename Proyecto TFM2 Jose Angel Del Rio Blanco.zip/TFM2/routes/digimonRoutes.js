const express = require('express');
const router = express.Router();
const db = require('../db');


router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM digimon ORDER BY RAND() LIMIT 12');
    res.json(rows);  
  } catch (error) {
    console.error('Error obteniendo digimons:', error);
    res.status(500).json({ error: 'Error al obtener la lista de Digimon' });
  }
});

const { verifyToken } = require('../middleware/authMiddleware');


router.post('/', verifyToken, async (req, res) => {
  const { name, level, attribute, img } = req.body;
  if (!name || !level || !img) {
    return res.status(400).json({ error: 'Faltan datos del Digimon (name, level, img son requeridos)' });
  }
  try {
    
    const result = await db.query(
      'INSERT INTO digimon (name, level, attribute, img) VALUES (?, ?, ?, ?)',
      [ name, level, attribute || null, img ]
    );
    res.status(201).json({ message: 'Digimon agregado correctamente' });
  } catch (error) {
    console.error('Error al agregar Digimon:', error);
    res.status(500).json({ error: 'No se pudo agregar el Digimon' });
  }
});


router.put('/:id', verifyToken, async (req, res) => {
  const digimonId = req.params.id;
  const { name, level, attribute, img } = req.body;
  try {
 
    const [result] = await db.query(
      'UPDATE digimon SET name = ?, level = ?, attribute = ?, img = ? WHERE id = ?',
      [ name, level, attribute || null, img, digimonId ]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Digimon no encontrado' });
    }
    res.json({ message: 'Digimon actualizado correctamente' });
  } catch (error) {
    console.error('Error al editar Digimon:', error);
    res.status(500).json({ error: 'No se pudo editar el Digimon' });
  }
});


router.delete('/:id', verifyToken, async (req, res) => {
  const digimonId = req.params.id;
  try {
    const [result] = await db.query('DELETE FROM digimon WHERE id = ?', [digimonId]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Digimon no encontrado' });
    }
    res.json({ message: 'Digimon eliminado correctamente' });
  } catch (error) {
    console.error('Error al eliminar Digimon:', error);
    res.status(500).json({ error: 'No se pudo eliminar el Digimon' });
  }
});




module.exports = router;
