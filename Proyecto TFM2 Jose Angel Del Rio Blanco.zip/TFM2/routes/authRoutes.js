const express = require('express');
const router  = express.Router();
const db      = require('../db');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { verifyToken }   = require('../middleware/authMiddleware');
const updateAlive       = require('../middleware/updateAlive'); 


router.post('/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Se requieren nombre de usuario y contraseña' });
  }
  try {
    const [users] = await db.query('SELECT id FROM users WHERE username = ?', [username]);
    if (users.length > 0) {
      return res.status(400).json({ message: 'El usuario ya existe. Elige otro nombre o inicia sesión.' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    await db.query(
      'INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
      [username, hashedPassword, 'user']
    );
    res.status(201).json({ message: 'Usuario registrado con éxito' });
  } catch (error) {
    console.error('Error en registro:', error);
    res.status(500).json({ error: 'Error del servidor al registrar usuario' });
  }
});


router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Se requieren nombre de usuario y contraseña' });
  }
  try {
    const [users] = await db.query('SELECT * FROM users WHERE username = ?', [username]);
    if (users.length === 0) {
      return res.status(400).json({ error: 'Credenciales incorrectas' });
    }
    const user = users[0];
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ error: 'Credenciales incorrectas' });
    }

    const token = jwt.sign(
      { userId: user.id, username: user.username, role: user.role || 'user' },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.json({
      message: 'Login exitoso',
      token,
      username: user.username,
      role: user.role || 'user',
      expiresIn: 3600,
      user: { username: user.username, role: user.role || 'user' }
    });
  } catch (error) {
    console.error('Error en login:', error);
    res.status(500).json({ error: 'Error del servidor al iniciar sesión' });
  }
});


router.get('/me', verifyToken, (req, res) => {
  res.json({ username: req.user.username, role: req.user.role });
});


router.get(
  '/admin/online-users',
  verifyToken,
  updateAlive,
  async (req, res) => {
    const threshold = new Date(Date.now() - 5 * 60 * 1000);
    const [rows] = await db.query(
      `SELECT u.username
         FROM users u
         JOIN active_users a ON u.id = a.user_id
        WHERE a.last_alive > ?`,
      [threshold]
    );
    res.json({
      count: rows.length,
      users: rows.map(r => r.username)
    });
  }
);

module.exports = router;
