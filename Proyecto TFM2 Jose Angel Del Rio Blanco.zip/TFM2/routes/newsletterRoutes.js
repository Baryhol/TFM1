const express = require('express');
const router = express.Router();
const db = require('../db');


router.post('/', async (req, res) => {
  const { email } = req.body;  // 
  if (!email) {
    return res.status(400).json({ error: 'Falta el email' });
  }
  try {
   
    await db.query('INSERT INTO newsletter (email) VALUES (?)', [email]);
    res.status(201).json({ message: '¡Gracias por suscribirte al newsletter!' });
  } catch (error) {
   
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ message: 'Este correo ya está suscrito.' });
    }
    console.error('Error al suscribir email:', error);
    res.status(500).json({ error: 'Error del servidor al suscribir correo' });
  }
});

module.exports = router;
