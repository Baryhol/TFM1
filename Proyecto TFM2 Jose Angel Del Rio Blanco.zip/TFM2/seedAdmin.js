const pool = require('./db');
const bcrypt = require('bcrypt');

(async () => {
  try {
    const [rows] = await pool.query('SELECT COUNT(*) as count FROM users');
    const count = rows[0].count;
    if (count === 0) {
      const defaultUsername = 'admin';
      const defaultPassword = '12345';
      const hashed = await bcrypt.hash(defaultPassword, 10);
      await pool.query(
        'INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
        [defaultUsername, hashed, 'admin']
      );
      console.log(`Admin seed creado: ${defaultUsername} / ${defaultPassword}`);
    } else {
      console.log(`(${count}) usuarios existentes. No se crea admin.`);
    }
    process.exit(0);
  } catch (err) {
    console.error('Error en seedAdmin:', err);
    process.exit(1);
  }
})();
