const jwt = require('jsonwebtoken');

function verifyToken(req, res, next) {
  const authHeader = req.headers['authorization'] || req.headers['Authorization'];
  if (!authHeader) {
    return res.status(401).json({ error: 'Acceso denegado. Falta token de autenticación.' });
  }
  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    return res.status(401).json({ error: 'Formato de token inválido. Usa "Bearer <token>"' });
  }
  const token = parts[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; 
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token inválido o expirado. Por favor, inicia sesión de nuevo.' });
  }
}


function requireAdminMiddleware(req, res, next) {
 
  if (!req.user.role || req.user.role.toLowerCase() !== 'admin') {
    return res.status(403).json({ error: 'No autorizado. Se requieren privilegios de administrador.' });
  }
  next();
}

module.exports = {
  verifyToken,
  requireAdminMiddleware
};
