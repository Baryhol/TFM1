const db = require('../db');

async function updateAlive(req, res, next) {
  if (req.user && req.user.userId) {
    const now = new Date();
    await db.query(
      `INSERT INTO active_users (user_id, last_alive)
       VALUES (?, ?)
       ON DUPLICATE KEY UPDATE last_alive = ?`,
      [req.user.userId, now, now]
    );
  }
  next();
}

module.exports = updateAlive;
