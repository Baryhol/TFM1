const SESSION_KEY = 'digimundo_session';


export interface Session {
  username: string;
  token: string;
  role: 'user' | 'admin';
  expiresAt: number;
}


export function setSession({ username, token, role, expiresIn }: {
  username: string;
  token: string;
  role: 'user' | 'admin';
  expiresIn: number; 
}): void {
  const expiresAt = Date.now() + expiresIn * 1000;
  const session: Session = { username, token, role, expiresAt };
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}


export function getSession(): Session | null {
  const raw = localStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  try {
    const session = JSON.parse(raw) as Session;
    if (Date.now() > session.expiresAt) {
      localStorage.removeItem(SESSION_KEY);
      return null;
    }
    return session;
  } catch {
    localStorage.removeItem(SESSION_KEY);
    return null;
  }
}


export function clearSession(): void {
  localStorage.removeItem(SESSION_KEY);
  window.location.href = '/login.html';
}


export function renderNavUser(): void {
  const navUser = document.getElementById('navUser');
  if (!navUser) return;
  const session = getSession();
  if (session) {
    navUser.innerHTML = `
      <span class="navbar-text text-white">${session.username}</span>
      <button id="logoutBtn" class="contact__button ms-2">Cerrar sesión</button>
    `;
    const btn = document.getElementById('logoutBtn');
    btn?.addEventListener('click', clearSession);
  } else {
    navUser.innerHTML = `
      <a id="loginBtn" href="/login.html" class="contact__button ms-2">Iniciar sesión</a>
    `;
  }
}


export function requireLogin(): void {
  if (!getSession()) {
    window.location.href = '/login.html';
  }
}


export function requireAdmin(): void {
  const session = getSession();
  if (!session) {
    window.location.href = '/login.html';
  } else if (session.role !== 'admin') {
    window.location.href = '/home.html';
  }
}
