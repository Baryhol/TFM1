import { renderNavUser, getSession } from './auth';

document.addEventListener('DOMContentLoaded', () => {
  
  renderNavUser();
  const session = getSession();
  const adminFooter = document.getElementById('adminFooterLink');
  if (session?.role === 'admin' && adminFooter) {
    adminFooter.classList.remove('d-none');
  }


  const contactForm = document.getElementById('contactForm') as HTMLFormElement | null;
  if (contactForm) {
    contactForm.addEventListener('submit', (e: Event) => {
      e.preventDefault();
      const responseDiv = document.getElementById('formResponse');
      if (responseDiv) {
        responseDiv.textContent = '¡Gracias por tu mensaje! Te responderemos a la brevedad.';
        responseDiv.style.display = 'block';
        setTimeout(() => { responseDiv.style.display = 'none'; }, 5000);
        contactForm.reset();
      }
    });
  }

  if (!localStorage.getItem('cookiesAccepted')) {
    const cookieBanner = document.createElement('div');
    cookieBanner.classList.add('cookie-banner');
    cookieBanner.innerHTML = `
      <p class=\"cookie-banner__text\">
        Usamos cookies para mejorar tu experiencia en el sitio.
        <a href=\"avisolegal.html\" class=\"cookie-banner__link\">Más información</a>
      </p>
      <button id=\"acceptCookies\" class=\"cookie-banner__button\">Aceptar</button>
    `;
    document.body.appendChild(cookieBanner);
    const acceptButton = document.getElementById('acceptCookies');
    if (acceptButton) {
      acceptButton.addEventListener('click', () => {
        localStorage.setItem('cookiesAccepted', 'true');
        cookieBanner.remove();
      });
    }
  }

 
  const subscribeForm = document.querySelector<HTMLFormElement>('.newsletter__form');
  const emailInput = document.querySelector<HTMLInputElement>('.newsletter__input');
  const responseMessage = document.querySelector<HTMLElement>('.newsletter__message');
  if (subscribeForm && emailInput && responseMessage) {
    subscribeForm.addEventListener('submit', async (e: Event) => {
      e.preventDefault();
      const email = emailInput.value.trim();
      if (!email) return;

      try {
        const res = await fetch('/api/newsletter', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email })
        });
        const data = await res.json();
        responseMessage.textContent = res.ok
          ? (data.message || '¡Gracias por suscribirte a nuestro newsletter!')
          : (data.message || 'No se pudo suscribir. ' + (data.error || ''));
        responseMessage.style.color = res.ok ? 'white' : 'red';
        if (res.ok) { emailInput.value = ''; }
      } catch (err) {
        console.error('Error en la suscripción:', err);
        responseMessage.textContent = 'Error de conexión. Por favor, intenta más tarde.';
        responseMessage.style.color = 'red';
      } finally {
        responseMessage.style.display = 'block';
        setTimeout(() => { responseMessage.style.display = 'none'; }, 5000);
      }
    });
  }
});
