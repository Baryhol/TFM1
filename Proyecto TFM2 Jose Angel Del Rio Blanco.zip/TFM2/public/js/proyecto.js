import { renderNavUser, getSession } from './auth.js';

document.addEventListener("DOMContentLoaded", () => {
  renderNavUser();


  const session = getSession();
  const adminFooter = document.getElementById("adminFooterLink");
  if (session?.role === 'admin' && adminFooter) {
    adminFooter.classList.remove("d-none");
  }

  const navMenu = document.querySelector('.header__nav-menu');

  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      const responseDiv = document.getElementById('formResponse');
      responseDiv.textContent = "¡Gracias por tu mensaje! Te responderemos a la brevedad.";
      responseDiv.style.display = "block";
      setTimeout(() => responseDiv.style.display = "none", 5000);
      contactForm.reset();
    });
  }

  if (!localStorage.getItem("cookiesAccepted")) {
    const cookieBanner = document.createElement("div");
    cookieBanner.classList.add("cookie-banner");
    cookieBanner.innerHTML = `
      <p class="cookie-banner__text">
        Usamos cookies para mejorar tu experiencia en el sitio.
        <a href="avisolegal.html" class="cookie-banner__link">Más información</a>
      </p>
      <button id="acceptCookies" class="cookie-banner__button">Aceptar</button>
    `;
    document.body.appendChild(cookieBanner);
    document.getElementById("acceptCookies").addEventListener("click", () => {
      localStorage.setItem("cookiesAccepted", "true");
      cookieBanner.remove();
    });
  }

  const subscribeForm = document.querySelector(".newsletter__form");
  const emailInput = document.querySelector(".newsletter__input");
  const responseMessage = document.querySelector(".newsletter__message");

  if (subscribeForm) {
    subscribeForm.addEventListener("submit", e => {
      e.preventDefault();
      const email = emailInput.value.trim();
      if (!email) return;

      fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email })
      })
        .then(async res => {
          const data = await res.json();
          responseMessage.textContent = res.ok
            ? (data.message || "¡Gracias por suscribirte a nuestro newsletter!")
            : (data.message || "No se pudo suscribir. " + (data.error || ""));
          responseMessage.style.color = res.ok ? "white" : "red";
          responseMessage.style.display = "block";
          if (res.ok) emailInput.value = "";
          setTimeout(() => responseMessage.style.display = "none", 5000);
        })
        .catch(err => {
          console.error("Error en la suscripción:", err);
          responseMessage.textContent = "Error de conexión. Por favor, intenta más tarde.";
          responseMessage.style.color = "red";
          responseMessage.style.display = "block";
          setTimeout(() => responseMessage.style.display = "none", 5000);
        });
    });
  }
});
