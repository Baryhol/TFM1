import { setSession, renderNavUser } from './auth.js';

document.addEventListener("DOMContentLoaded", () => {
  renderNavUser(); 

  const form = document.getElementById("loginForm");
  const message = document.getElementById("loginMessage");

  form.username.setAttribute("autocomplete", "username");
  form.password.setAttribute("autocomplete", "current-password");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = form.username.value.trim();
    const password = form.password.value.trim();

    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      console.log("Login response:", data);

      if (res.ok) {
        
        const role = (data.role || (data.user && data.user.role) || 'user').toLowerCase();

        setSession({
          username: data.username || (data.user && data.user.username) || username,
          token: data.token,
          role: role,
          expiresIn: data.expiresIn || 3600
        });

        const target = role === 'admin' ? '/admin.html' : '/home.html';
        window.location.href = target;
      } else {
        message.textContent = data.message || data.error || "Login fallido";
        message.style.backgroundColor = "#f8d7da";
      }
    } catch (err) {
      console.error("Error en login:", err);
      message.textContent = "Error de conexión.";
      message.style.backgroundColor = "#f8d7da";
    }
  });
});
