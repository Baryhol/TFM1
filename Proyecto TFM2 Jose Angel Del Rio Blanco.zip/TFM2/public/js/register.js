import { renderNavUser } from './auth.js';

document.addEventListener("DOMContentLoaded", () => {
  renderNavUser();

  const form = document.getElementById("registerForm");
  const message = document.getElementById("registerMessage");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = form.username.value.trim();
    const password = form.password.value.trim();

    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();

      if (res.ok) {
        message.textContent = "Registro exitoso. Redirigiendo al login…";
        message.style.backgroundColor = "#dff0d8";
        setTimeout(() => window.location.href = "/login.html", 1500);
      } else {
        message.textContent = data.message || data.error || "Registro fallido";
        message.style.backgroundColor = "#f8d7da";
      }
    } catch (error) {
      message.textContent = "Error al conectar con el servidor.";
      message.style.backgroundColor = "#f8d7da";
    }
  });
});