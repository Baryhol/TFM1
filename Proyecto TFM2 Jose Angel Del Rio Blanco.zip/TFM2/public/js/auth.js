const SESSION_KEY = 'digimundo_session';


export function setSession({ username, token, role, expiresIn }) {
  const expiresAt = Date.now() + expiresIn * 1000;
  localStorage.setItem(
    SESSION_KEY,
    JSON.stringify({ username, token, role, expiresAt })
  );
}


export function getSession() {
  const raw = localStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  const session = JSON.parse(raw);
  if (Date.now() > session.expiresAt) {
    localStorage.removeItem(SESSION_KEY);
    return null;
  }
  return session;
}


export function clearSession() {
  localStorage.removeItem(SESSION_KEY);
  window.location.href = '/login.html';
}


export function renderNavUser() {
  const navUser = document.getElementById('navUser');
  if (!navUser) return;
  const session = getSession();
  if (session) {
    navUser.innerHTML = `
      <span class="navbar-text text-white">${session.username}</span>
      <button id="logoutBtn" class="contact__button ms-2">Cerrar sesión</button>
    `;
    document.getElementById('logoutBtn').addEventListener('click', clearSession);
  } else {
    navUser.innerHTML = `<a id="loginBtn" href="/login.html" class="contact__button ms-2">Iniciar sesión</a>`;
  }
}


export function requireLogin() {
  if (!getSession()) {
    window.location.href = '/login.html';
  }
}


export function requireAdmin() {
  const session = getSession();
  if (!session) {
    
    window.location.href = '/login.html';
  } else if (session.role !== 'admin') {
    
    window.location.href = '/home.html';
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const isAdmin = localStorage.getItem("isAdmin") === "true";
  const adminLink = document.getElementById("adminLink");
  if (isAdmin && adminLink) {
    adminLink.classList.remove("d-none");
  }

  
  const username = localStorage.getItem("username");
  const navUser = document.getElementById("navUser");

  if (username && navUser) {
    navUser.innerHTML = `
      <span class="badge">${username}</span>
      <a href="logout.html" class="btn btn-outline-light btn-sm">Salir</a>
    `;
  }
});
