document.addEventListener('DOMContentLoaded', () => {
  const form      = document.getElementById('contactForm');
  const statusDiv = document.getElementById('formResponse');

 
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type=submit]');
    btn.disabled = true;
    statusDiv.textContent = '';
    statusDiv.className = 'contact__response';

    const payload = {
      nombre:  form.nombre.value.trim(),
      email:   form.email.value.trim(),
      mensaje: form.mensaje.value.trim()
    };

    try {
      const res = await fetch('/api/contacto', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(payload)
      });
      if (!res.ok) throw new Error(`Status ${res.status}`);
      const json = await res.json();
      statusDiv.textContent = json.success
        ? '¡Mensaje enviado con éxito! ID: ' + json.id
        : 'Error: ' + (json.error || 'respuesta inesperada');
      statusDiv.classList.add(
        json.success ? 'alert':'alert-success' , 'alert','alert-danger'
      );
      if (json.success) form.reset();
    } catch (err) {
      statusDiv.textContent = 'Error al enviar: ' + err.message;
      statusDiv.classList.add('alert','alert-danger');
    } finally {
      btn.disabled = false;
    }
  });
});
