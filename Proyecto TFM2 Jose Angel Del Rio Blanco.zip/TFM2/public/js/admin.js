import { renderNavUser, getSession, clearSession } from './auth.js';

document.addEventListener("DOMContentLoaded", async () => {
  renderNavUser();


  try {
    const session = getSession();
    if (!session) throw new Error();

    const resp = await fetch('/api/me', {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.token}`
      }
    });
    if (!resp.ok) throw new Error();
    const me = await resp.json();
    if (me.role.toLowerCase() !== 'admin') throw new Error();
  } catch {
    clearSession();
    window.location.href = 'login.html';
    return;
  }


  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', event => {
      event.preventDefault();
      clearSession();
      window.location.href = 'login.html';
    });
  } else {
    console.error('logoutBtn no encontrado en el DOM');
  }


  const addBtn = document.getElementById('addDigimonBtn');
  const formContainer = document.getElementById('addDigimonFormContainer');
  if (addBtn && formContainer) {
    addBtn.addEventListener('click', () => {
      formContainer.classList.toggle('d-none');
    });
  }

 
  const addForm = document.getElementById('addDigimonForm');
  if (addForm) {
    ['name','level','img'].forEach(field => {
      addForm[field].setAttribute('autocomplete', 'off');
    });
    addForm.addEventListener('submit', async e => {
      e.preventDefault();
      const session = getSession();
      const payload = {
        name: addForm.name.value.trim(),
        level: addForm.level.value.trim(),
        img: addForm.img.value.trim()
      };
      try {
        const res = await fetch('/api/digimon', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.token}`
          },
          body: JSON.stringify(payload)
        });
        if (!res.ok) throw new Error('Error al agregar Digimon');
        alert('Digimon agregado correctamente');
        addForm.reset();
      } catch (err) {
        alert(err.message);
      }
    });
  }


  async function loadOnlineUsers() {
    const session = getSession();
    try {
      const res = await fetch('/api/admin/online-users', {
        headers: { 'Authorization': `Bearer ${session.token}` }
      });
      if (!res.ok) throw new Error();
      const { count, users } = await res.json();
      document.getElementById('onlineCount').textContent = count;
      const ul = document.getElementById('onlineUsersList');
      ul.innerHTML = users.map(u => `<li>${u}</li>`).join('');
    } catch (err) {
      console.error('Error cargando usuarios en línea:', err);
    }
  }
  loadOnlineUsers();
});