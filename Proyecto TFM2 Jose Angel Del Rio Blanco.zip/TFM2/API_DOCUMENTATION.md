# Documentación de la API

Este documento recoge la especificación de los endpoints de la API desarrollada en Node.js/Express.

---

## 1. Descripción general
La API expone servicios para gestionar usuarios, autenticación JWT, CRUD de Digimon, newsletter y mensajes de contacto. Los endpoints se agrupan en rutas públicas (sin token) y privadas (token JWT requerido).

## 2. Esquema de autenticación
- **Registro**: `POST /api/register` (público)  
- **Login**: `POST /api/login` (público)  
- **Token JWT**: se obtiene en el login y debe enviarse en el header `Authorization: Bearer <token>` para las rutas privadas.  
- **Roles**: el JWT incluye el campo `role` (`user` o `admin`).

## 3. Endpoints

### 3.1 Usuarios

| Método | Ruta                         | Privacidad | Descripción                                             |
|--------|------------------------------|------------|---------------------------------------------------------|
| POST   | `/api/register`              | Pública    | Crea nuevo usuario. Request: `{ username, password }`   |
| POST   | `/api/login`                 | Pública    | Autentica usuario. Request: `{ username, password }`    |
| GET    | `/api/me`                    | Privada    | Devuelve `{ username, role }` del token.                |
| GET    | `/api/admin/online-users`    | Privada    | Lista usuarios activos últimos 5min.                    |

### 3.2 Digimon

| Método | Ruta                      | Privacidad | Descripción                                                        |
|--------|---------------------------|------------|--------------------------------------------------------------------|
| GET    | `/api/digimon`            | Pública    | Lista 12 Digimon aleatorios.                                       |
| POST   | `/api/digimon`            | Privada    | Crea Digimon. Body: `{ name, level, attribute?, img }`. Respuesta 201. |
| PUT    | `/api/digimon/:id`        | Privada    | Actualiza Digimon por `id`.                                         |
| DELETE | `/api/digimon/:id`        | Privada    | Elimina Digimon por `id`.                                           |

### 3.3 Contacto y Newsletter

| Método | Ruta                   | Privacidad | Descripción                                                  |
|--------|------------------------|------------|--------------------------------------------------------------|
| POST   | `/api/contacto`        | Pública    | Envía mensaje de contacto. Body: `{ nombre, email, mensaje }` |
| POST   | `/api/newsletter`      | Pública    | Suscribe al newsletter. Body: `{ email }`. 201 en éxito.      |

## 4. Ejemplo de uso (cURL)
```bash
# Registro
curl -X POST http://localhost:3000/api/register   -H "Content-Type: application/json"   -d '{"username":"juan","password":"1234"}'

# Login
curl -X POST http://localhost:3000/api/login   -H "Content-Type: application/json"   -d '{"username":"juan","password":"1234"}'

# Crear Digimon (privado)
curl -X POST http://localhost:3000/api/digimon   -H "Content-Type: application/json"   -H "Authorization: Bearer <TU_TOKEN>"   -d '{"name":"Agumon","level":"Rookie","img":"url"}'
```
